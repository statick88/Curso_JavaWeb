package com.example.RegistroUsuariosApplication;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class RegistroUsuariosApplicationTests {

	@Test
	void contextLoads() {
	}

}
