package com.example.RegistroUsuariosAplication.Users;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import java.util.HashMap;
import java.util.List;
import java.util.Optional;

@Service
public class UserService {

    private final UserRepository userRepository;

    @Autowired
    public UserService(UserRepository userRepository) {
        this.userRepository = userRepository;
    }

    public List<UserAplication> getUsers() {
        return this.userRepository.findAll();
    }

    public ResponseEntity<Object> newUser(UserAplication user) {
        Optional<UserAplication> existingUser = userRepository.findUserAplicationByName(user.getName());
        HashMap<String, Object> datos = new HashMap<String, Object>();

        if (existingUser.isPresent() && user.getId() == null) {
            datos.put("data", true);
            datos.put("message", "El usuario ya existe");
            return new ResponseEntity<>(
                    datos,
                    HttpStatus.CONFLICT
            );
        } else {
            userRepository.save(user);
            datos.put("data", user);
            if (user.getId() != null) {
                datos.put("message", "Usuario actualizado");
            } else {
                datos.put("message", "Usuario creado");
            }
            HttpStatus status = user.getId() != null ? HttpStatus.OK : HttpStatus.CREATED;
            return new ResponseEntity<>(
                    datos,
                    status
            );
        }
    }
}
