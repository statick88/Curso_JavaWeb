package com.example.RegistroUsuariosApplication;

import com.example.RegistroUsuariosApplication.Users.User;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

@SpringBootApplication
@RestController
public class RegistroUsuariosApplication {

	public static void main(String[] args) {
		SpringApplication.run(RegistroUsuariosApplication.class, args);

	} 
@GetMapping
public List<User> getNames(){
	return List.of(
		new User(
		1L,
		"Juan",
		"juan@email.com",
		"password",
		"123456789",
		"Av. Siempre Viva 123",
		"Springfield"
	));
	}
}